const { Schema, model } = require("mongoose");

const usercart = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    eventTickets:[]
  },
);

module.exports = model("usercart", usercart);

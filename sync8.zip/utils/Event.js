const Event = require("../models/Event");
const User = require("../models/User");
const usercart = require('../models/usercart');

const createEvent = async (eventData, res) => {
    const event = new Event({
        ...eventData
    });

    await event.save();
    return res.status(201).json({
        message: "You have successfully created an event",
        success: true
    });
}


const getEvent = async (req,res) => {
    all = await Event.find((err, docs) => {
        if (!err) {
            //console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
    bought=await usercart.find({email:req.params.email},(err,docs)=>{
        if (!err) {
            //console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    })
    res.send(all+bought);
    //return docs;
}

const getCategory = async(data,res)=>{
    console.log(data)
    all = await Event.find( { 'category': data },(err, docs) => {
        if (!err) {
            res.send(docs);
            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
  
}

const getAllCategory= async(res)=>{
    all = await Event.find((err, docs) => {
        if (!err) {
            res.send(docs);
            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
}


const liveEvent = async(req,res)=>{
    all = await Event.find({status:"live"},(err, docs) => {
        if (!err) {

            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
    bought=await usercart.find({email:req.params.email},(err,docs)=>{
        if (!err) {
            //console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    })
    //res.send(all,{bought});
    return res.status(201).json({
        event: all,
        ticket: bought
    });
}

const preRecorded = async(req,res)=>{
    all = await Event.find({status:"recoded"},(err, docs) => {
        if (!err) {
            //res.send(docs);
            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
    bought=await usercart.find({email:req.params.email},(err,docs)=>{
        if (!err) {
            //console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    })
    return res.status(201).json({
        event: all,
        ticket: bought
    });
}

const upComing = async(req,res)=>{
    all = await Event.find({status:"upcoming"},(err, docs) => {
        if (!err) {
            //res.send(docs);
            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
    bought=await usercart.find({email:req.params.email},(err,docs)=>{
        if (!err) {
            //console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    })
    return res.status(201).json({
        event: all,
        ticket: bought
    });
}

const deleteEvent= async(id,res)=>{
    await Event.findByIdAndDelete({_id:id},(err,docs)=>{
        if(!err){
            res.send("Deleted").status(200)
        }
    })
}

// const like= async(req,res)=>{
//     console.log("like",req.body.email)
//     await Event.find(
//         {email : req.body.email}
//         ,(err,docs)=>{
//             if(!err){console.log(docs[0].email)}
//             else{console.log(err)}
//         // if(docs.length==0){
//         //     //createComment(req,res)
//         //     console.log("does not exist",docs[0])
//         //     commentExist(req,res)
//         // }
//         // if(docs.length>0){
//         //     commentExist(req,res)
//         //     console.log("exist",docs[0])
//         // }
//         // else{
//         //     console.log(err)
//         // }
//     })
// }

const createComment=(req,res)=>{
    //PersonModel.find({ favouriteFoods: { "$in" : ["sushi"]} }, ...);
    //Person.update({'items.id': 2}, {'$set':  {'items.$': update}}, function(err)
    // const email = req.body.email;
    // const query = {
    //   comments.email: email 
    // };
    // Event.findOne({}).then(doc => {
    //   item = doc.items.id(itemId );
    //   item["name"] = "new name";
    //   item["value"] = "new value";
    //   doc.save();
    
    //   //sent respnse to client
    // }).catch(err => {
    //   console.log('Oh! Dark')
    // });
}

const like=(req,res)=>{
    //like status Y/N total likes
    console.log(req.body.email,req.body.eventid)
    Event.find({_id:req.body.eventid},(err,docs)=>{
        if(docs.length==0){
            console.log("not present")
            res.send(docs)
        }
        if(docs.length>0){
            console.log("present")
            res.send(docs)
            increaseLike(docs[0]._id,docs[0].like)
        }
        else{
            console.log(err)
        }
    })
}

const increaseLike=(id,like)=>{
    console.log(id,like)
    likee=like+1
    Event.updateOne({_id:id},{like:likee},(err)=>{
        if(!err){console.log(err)}
    })
}

const comment=(req,res)=>{
    console.log(req.body.email,req.body.eventid,req.body.comment)
    Event.updateOne({_id:req.body.eventid},{
        $push: {
            comments: {
              "email:": req.body.email,
              "comment":req.body.comment
            },
          }
    },(err)=>{
        if(!err){
            return res.status(201).json({
                message: "Thank You For Your Comment.",
                success: true
            });
        }
        else(console.log(err))
    })
}

const commentExist=(req,res)=>{
    Event.findOneAndUpdate({email: req.body.email}, {
        $push: {
            comments: {
                "email:": req.body.products[0].email,
                "comment": req.body.products[0].comment
            },
        }
    })
    res.sendStatus(200)
}

module.exports = {
    createEvent,
    getEvent,
    getCategory,
    getAllCategory,
    liveEvent,
    preRecorded,
    upComing,
    deleteEvent,
    like,
    comment
};
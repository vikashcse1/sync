const { Schema, model } = require("mongoose");

const query = new Schema(
  {
    email: {
      type: String,
      required: true
    },
   query:{
       type:String,
       requireL:true
   }
  },
  { timestamps: true }
);

module.exports = model("query", query);

const { Schema, model } = require("mongoose");

const PromoterSchema = new Schema(
  {
    profile_pic:{
      type:String
    },
    name: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    },
    phone: {
      type: String,
      required: true
    },
    password: {
      type: String,
      required: true
    },
    user_description:{
      type:String
    },
    following:[]
  },
  { timestamps: true }
);

module.exports = model("Promoter", PromoterSchema);

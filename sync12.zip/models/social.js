const { Schema, model } = require("mongoose");

const social = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    type: {
        type: String,
        required: true
      },
    password:String,
    name:String
  },
);

module.exports = model("social", social);

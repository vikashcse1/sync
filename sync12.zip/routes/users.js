const router = require("express").Router();
const User = require("../models/User");
const query = require('../models/query')
const usercart = require('../models/usercart')
const Event = require('../models/Event')
const social = require('../models/social')
const cors = require("cors");

// Bring in the User Registration function
const {
  userAuth,
  userLogin,
  checkRole,
  userRegister,
  serializeUser,
  createEvent,
  getAllEvent,
  getUserList,
  resetPassword,
  verify,
  forgetPassword,
  changePassword,
  getEventEmail,
  notifymy,
  deletUser
} = require("../utils/Auth");

router.post('/search', (req, res) => {
  console.log("search   " + req.body.search)
  //res.send(req.body)
  Event.find({ $text: { $search: req.body.search } }
    , (err, docs) => {
      if (!err) {
        res.send({ docs })
        console.log(docs)
      }
      else {
        console.log(err)
      }
    }
  )
})


// Users Registeration Route
router.post("/register-user", async (req, res) => {
  await userRegister(req.body, "user", res);
});

// Admin Registration Route
router.post("/register-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// Super Admin Registration Route
router.post("/register-super-admin", async (req, res) => {
  await userRegister(req.body, "superadmin", res);
});

// Users Login Route
router.post("/login-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin Login Route
router.post("/login-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});

// Super Admin Login Router


router.post("/login-super-admin", async (req, res) => {

  await userLogin(req.body, "superadmin", res);
});

// Profile Route
router.get("/profile", async (req, res) => {
  User.find({ email: req.body.email }, (err, docs) => {
    if (!err) {
      //console.log(serializeUser(docs[0]))
      return res.json(serializeUser(docs[0]));
    } else {
      console.log(err)
    }
  })

});

// Users Protected Route
router.get(
  "/user-protectd",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    return res.json("Hello User");
  }
);

// Admin Protected Route
router.get(
  "/admin-protectd",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    return res.json("Hello Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-protectd",
  userAuth,
  checkRole(["superadmin"]),
  async (req, res) => {
    return res.json("Hello Super Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-and-admin-protectd",
  userAuth,
  checkRole(["superadmin", "admin"]),
  async (req, res) => {
    return res.json("Super admin and Admin");
  }
);

//creating Events 
router.post('/createEvent', async (req, res) => {
  await createEvent(req.body, res)
})

//geting all events
router.get('/getEvents', async (req, res) => {
  await getAllEvent(res)
})

//geting all users
router.get('/getUserList', async (req, res) => {
  await getUserList(res)
})
//password reset 
router.post('/resetPassword', async (req, res) => {
  console.log("Reset Password")
  await resetPassword(req, res)
})
//verify otp and save new pass
router.post('/verify', async (req, res) => {
  await verify(req, res)
})

// Change Password
router.post('/changePassword', async (req, res) => {
  await changePassword(req, res)
})

router.post('/anyQuery', async (req, res) => {
  data = req.body
  const quer = new query({ ...data })
  quer.save()
  res.status(201).json({
    message: "Successfully Submited Your Query",
    success: true
  });

})

router.post('/usercart', async (req, res) => {
  await User.find({ email: req.body.email }, (err, docs) => {
    if (docs.length == 0) {
      console.log("not present")
      res.status(404).send("User Not Found")
    }
    if (docs.length > 0) {
      userexistcreatecart(req, res)
    }
    else {
      console.log(err)
    }
  })
  //const newticket= new usercart()
})


const userexistcreatecart = (req, res) => {
  console.log("present  1=" + req.body.email)
  usercart.find({ email: req.body.email }, (err, docs) => {
    console.log(docs.length)
    if (docs.length == 0) {
      console.log("length 0 " + docs)
      createusercart(req, res);
    }
    if (docs.length > 0) {
      console.log("length 1 " + docs)
      addtousercart(req, res)
    }
    else { console.log(err) }
  })
}


const createusercart = (req, res) => {
  console.log("present 0 11    " + req)
  const createNewCart = new usercart({
    ...req.body
  }, (err, docs) => {
    if (!err) { console.log(docs) }
    else { console.log(err) }
  })
  createNewCart.save()
}

const addtousercart = (req, res) => {
  console.log("present add" + req.body.email)
  usercart.findOneAndUpdate({
    email: req.body.email
  }, {
    $push: {
      eventTickets: {
        "event_name:": req.body.eventTickets[0].event_name,
        "event_id": req.body.eventTickets[0].event_id
      },
    }
  }, (err, docs) => {
    if (!err) {
      res.status(201).json({
        message: "Successfully Added To Cart",
        success: true
      });
    }
    else (console.log(err))
  })

}

router.get('/getTickets', (req, res) => {
  usercart.findOne({ email: req.body.email }, (err, docs) => {
    if (!err) {
      res.send(docs)
    }
  })
})

router.post('/cart', (req, res) => {
  usercart.find((err, docs) => {
    if (!err) {
      res.send(docs)
    }
    else {
      console.log(err)
    }
  })
})

router.post('/social', (req, res) => {


    social.find({ email: req.body.email }, (err, docs) => {
      if (docs.length == 0) {
        const soc = new social({ ...req.body })
        soc.save()
        res.send(200)
      }
      else if (docs.length > 0) {
        res.send(docs)
      }
      else {
        console.log(err)
      }
    })
  







  // social.find({email:req.body.email},(err,docs)=>{
  //   if(docs.length==0){
  //     const soc=new social({...req.body})
  //     soc.save()
  //     res.send(200)
  //   }
  //   else if(docs.length>0){
  //     res.send(docs)
  //   }
  //   else{
  //     console.log(err)
  //   }
  // })


})

//router.get('/editProfile'){// user & promoter

//recent search

//all event viewers
//notification
//notify me event 
//


router.post('/getuserevents', (req, res) => {
  console.log(req.protocol + '://' + req.get('host') + req.originalUrl)
  getEventEmail(req.body.email, res)
})

router.post('/notifications', (req, res) => {
  notifymy(req, res)
})



// router.post("/verify", async (req, res) => {
//   await verify(req.body, res);
// });


// router.post('/mail', async(req,res)=>{
//   await forgetPassword(req.body,res)
// })

// router.post('/:id',async (req,res)=>{
//   console.log(req.params)
//   res.send('What the hell')
// })

// router.post('/changepass/:secret',(req,res)=>{
//   console.log(req.params)
//   console.log(req.body)
//   console.log(req.body.password)
//   console.log(req.body.confirmpassword)
//   if(req.body.password==req.body.confirmpassword){
//     res.send("Password Changed")
//   }
//   if(req.body.password!=req.body.confirmpassword){
//     res.send("Password Does Not Match")
//   }
// })

//Delete User
router.post('/deletUser', (req, res) => {
  deletUser(req, res)
})

module.exports = router;




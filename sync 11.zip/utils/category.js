const category = require("../models/category");
const event = require("../models/Event")

const createCategory = async (data,filename, res) => {
    const cate = new category({
        ...data,
        category_image:filename
    });

    await cate.save();
    return res.status(201).json({
        message: "You have successfully created an category",
        success: true
    });
}

const getAllCategory= async(res)=>{
    all = await category.find((err, docs) => {
        if (!err) {
            res.send(docs);
            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
}

const getCategory= async(data,res)=>{
    all = await event.find({"category":data},(err, docs) => {
        if (!err) {
            res.send(docs);
            //return docs;
            console.log(docs);
        }
        else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
    });
}

const updateCategory= async(req,res)=>{
    await category.findByIdAndUpdate({_id:req.body.id},{category_image:req.body.category_image},(err,docs)=>{
        if(!err){
            console.log(docs)
        }
        else{
            console.log(err)
        }
    })
}

const deleteCategory = async (req,res)=>{
    await category.findOneAndDelete({_id:req.body.id},(err)=>{
        if(!err){
            res.send(200)
        }
        else{
            console.log(err)
        }
    })
}




module.exports = {
    createCategory,
    getAllCategory,
    getCategory,
    updateCategory,
    deleteCategory
    
};
const { Schema, model } = require("mongoose");

const notifications = new Schema(
  {
    email: {
      type: String,
      required: true
    },
    notifications:[]
  },
);

module.exports = model("notifications", notifications);

const router = require("express").Router();
const Event = require("../models/Event");
const cors = require("cors");
const multer = require('multer');



//storage startegy
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
      cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
      cb(null, file.originalname)
  }
});
//file filter
const fileFilter = (req, file, cb) => {
  //reject file
  if (file.mimetype === 'image/jpg' ||file.mimetype === 'image/jpeg'||file.mimetype === 'image/png') {
      cb(null, true);
  } 
  else{
  cb(new Error('Message wrong file type.'), false);
  }
}

const upload = multer({ 
  storage: storage ,
  fileFilter:fileFilter
});



var cpUpload = upload.fields([{ name: 'banner', maxCount: 1 }, { name: 'promoter_image', maxCount: 1 }])

// Bring in the Event function
const {
    createEvent,
    getEvent,
    getEventDashboard,
    getCategory,
    getAllCategory,
    liveEvent,
    preRecorded,
    upComing,
    deleteEvent,
    like,
    comment
} = require("../utils/Event");
const usercart = require("../models/usercart");

// Create Event
router.post("/createEvent", upload.single("banner"), async (req, res) => {
  //await createEvent(req.body, "user", res);
  //console.log(req.body)
  
  banner=String(req.protocol+"://"+req.hostname+":3000/"+req.file.destination+req.file.originalname)
  console.log(req.file)
  console.log(req.body)
  await createEvent(req.body,banner, res);
});

// Get Event
router.get("/getEvent/:email", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  console.log(req.params)
  await getEvent(req,res);
});

// Get Event
router.get("/getEvent", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  //console.log(req.params)
  await getEventDashboard(req,res);
});

// Get Event
router.get("/getCategory", async (req, res) => {
    //await getEvent(req.body, "admin", res);
    
    let cat=req.body.category
    if(!cat){
      await getCategory(cat,res);
    }
    if(cat==[]){
      await getAllCategory(res);
    }
    
  });

  // Get Event
router.get("/live/:email", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await liveEvent(req,res);
});
// Get Event
router.get("/recoded/:email", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await preRecorded(req,res);
});
// Get Event
router.get("/upcoming/:email", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await upComing(req,res);
});

router.post('/delete',async(req,res)=>{
  await deleteEvent(req.body._id,res)
  console.log("delete   "+req.body._id)
})

router.post('/like',(req,res)=>{
  console.log(req.body.email,req.body.eventid)
  like(req,res)
})

router.post('/comment',(req,res)=>{
  console.log(req.body.email,req.body.eventid,req.body.comment)
  comment(req,res)
})


router.post('/eventUpdate',(req,res)=>{
  console.log(req.body.eventid,req.body.video_link)
  //Event.findOneAndUpdate({_id:req.body.eventid},{video_link:req.body.video_link})
})


module.exports = router;




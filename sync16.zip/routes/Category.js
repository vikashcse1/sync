const router = require("express").Router();
const Event = require("../models/category");
const multer = require('multer');


//storage startegy
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname)
    }
});
//file filter
const fileFilter = (req, file, cb) => {
    //reject file
    if (file.mimetype === 'image/jpg' ||file.mimetype === 'image/jpeg'||file.mimetype === 'image/png') {
        cb(null, true);
    } 
    else{
    cb(new Error('Message wrong file type.'), false);
    }
}

const upload = multer({ 
    storage: storage,
    fileFilter:fileFilter
});

// Bring in the Event function
const {
    createCategory,
    getAllCategory,
    getCategory,
    updateCategory,
    deleteCategory
} = require("../utils/category");

// Create Event
router.post("/createCategory",upload.single('category_image'), async (req, res) => {
  //await createEvent(req.body, "user", res);
  //console.log(req.body)
  //console.log(req.file)
  //res.send(req.file)
  Image=String(req.protocol+"://"+req.hostname+":3000/"+req.file.destination+req.file.originalname)
  await createCategory(req.body,Image, res);
});

// Get Event
router.get("/", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  console.log('get all category')
  await getAllCategory(res);
});

// Get Event
router.get("/getCategory", async (req, res) => {
    //await getEvent(req.body, "admin", res);
    //console.log(req.body.category)
    let cat=req.body.category
    await getCategory(cat,res);
});

router.post('/updateCategory', async(req,res)=>{
    await updateCategory(req,res)
})

router.post('/deleteCategory', async(req,res)=>{
    await deleteCategory(req,res)
})

module.exports = router;




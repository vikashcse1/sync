const { Schema, model } = require("mongoose");

const likee = new Schema(
  {
    email: {
      type: String,
      required: true
    },
   eventid:{
       type:String,
       requireL:true
   }
  }
);

module.exports = model("likee", likee);

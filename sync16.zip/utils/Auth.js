const authenticator = require('authenticator');
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const passport = require("passport");
const User = require("../models/User");
const Event = require("../models/Event");
const resetPass = require("../models/ResetPassword");
const notifications = require("../models/notifications");
const { SECRET } = require("../config");
const speakeasy = require("speakeasy");
const rn = require('random-number');
var options = {
  min: 111111,
  max: 999999,
  integer: true
}

const {
  mail
} = require("../utils/mailer");
const usercart = require('../models/usercart');


/**
 * @DESC To register the user (ADMIN, SUPER_ADMIN, USER)
 */
const userRegister = async (userDets,profile_pic, role, res) => {

  try {
    if (userDets.type == "Google" || userDets.type == "Facebook") {
      //name
      //email
      User.find({ email: userDets.email }, (err, docs) => {
        if (docs.length == 0) {
          createFG(userDets,res)
        }
        if (docs.length > 0) {
          loginFG(userDets,res)
        }
        else { console.log(err) }
      })
    }
    // Validate the username
    // let usernameNotTaken = await validateUsername(userDets.username);
    // if (!usernameNotTaken) {
    //   return res.status(400).json({
    //     message: `Username is already taken.`,
    //     success: false
    //   });
    // }

    // validate the email
    let emailNotRegistered = await validateEmail(userDets.email);
    if (!emailNotRegistered) {
      return res.status(400).json({
        message: `Email is already registered.`,
        success: false
      });
    }

    // Get the hashed password
    const password = await bcrypt.hash(userDets.password, 12);
    // create a new user
    var role;

    const newUser = new User({
      ...userDets,
      password,
      role,
      profile_pic:profile_pic
    });

    await newUser.save((err, docs) => {
      if (!err) {
        return res.status(201).json({
          message: "You are successfully registred. Please login.",
          success: true,
          data: docs
        });
      }
    });

  } catch (err) {
    // Implement logger function (winston)
    return res.status(500).json({
      message: "Unable to create your account.",
      success: false
    });
  }
};

/**
 * 
 * @DESC To Login the user (ADMIN, SUPER_ADMIN, USER)
 */
const userLogin = async (userCreds, role, res) => {
  //type Form Google Facebook
  let { email, password } = userCreds;
  // First Check if the username is in the database
  const user = await User.findOne({ email });
  if (!user) {
    return res.status(200).json({
      message: "Email is not found. Invalid login credentials.",
      success: false
    });
  }
  // We will check the role
  if (user.role !== role) {
    return res.status(200).json({
      message: "Please make sure you are logging in from the right portal.",
      success: false
    });
  }
  // That means user is existing and trying to signin fro the right portal
  //Now check for the password
  let isMatch = await bcrypt.compare(password, user.password);
  if (isMatch) {
    // Sign in the token and issue it to the user
    let token = jwt.sign(
      {
        user_id: user._id,
        username: user.username,
        role: user.role,
        phone: user.phone,
        email: user.email
      },
      SECRET,
      { expiresIn: "60 days" }
    );

    let result = {
      username: user.username,
      phone: user.phone,
      role: user.role,
      email: user.email,
      token: `Bearer ${token}`,
      expiresIn: 168

    };

    return res.status(200).json({
      ...result,
      message: "Hurray! You are now logged in.",
      success: true,
    });
  } else {
    return res.status(200).json({
      message: "Incorrect password.",
      success: false
    });
  }
};

// const validateUsername = async username => {
//   let user = await User.findOne({ username });
//   return user ? false : true;
// };

/**
 * @D
 * +ESC Passport middleware
 */
const userAuth = passport.authenticate("jwt", { session: false });

/**
 * @DESC Check Role Middleware
 */
const checkRole = roles => (req, res, next) =>
  !roles.includes(req.user.role)
    ? res.status(200).json("Unauthorized")
    : next();

const validateEmail = async email => {
  let user = await User.findOne({ email });
  return user ? false : true;
};

const serializeUser = user => {
  return {
    phone: user.phone,
    email: user.email,
    name: user.name,
    following: user.following,
    _id: user._id,
    updatedAt: user.updatedAt,
    createdAt: user.createdAt
  };
};

const createEvent = async (eventData, res) => {
  const event = new Event({
    ...eventData
  });

  await event.save();
  return res.status(201).json({
    message: "You have successfully created an event",
    success: true
  });
}

const getAllEvent = async (res) => {
  all = await Event.find((err, docs) => {
    if (!err) {
      res.send(docs);
      return docs;
      //console.log(docs);
    }
    else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
  });
}


const getUserList = async (res) => {

  all = await User.find((err, docs) => {
    if (!err) {
      res.send(docs);
      return docs;
      console.log(docs);
    }
    else { console.log('Error:' + JSON.stringify(err, undefined, 2)); }
  });
  console.log(all)

};


const validateEmailReturnID = async (email) => {
  console.log("dffffffff" + email)
  let user = await User.findOne({ email: email }, (err, docs) => {
    if (!err) { console.log(docs) }
  });
  return user.email;
  console.log(user._id)
};


//-------------------------
const resetPassword = async (req, res) => {
  otp = rn(options)
  email = req.body.email
  console.log(req.body.email, otp)
  User.find({ email: req.body.email }, (err, docs) => {
    if (docs.length == 0) {

      console.log("create new " + docs)
      res.status(201).json({
        message: "User Does Not Exist.",
        success: true
      });
    }
    if (docs.length > 0) {
      console.log("update " + docs)
      checkforotp(req, res)
      // resetPass.findOneAndUpdate({email:req.body.email},{otp:otp})
      // mail(req.body.email,String(otp))
    }
    else { console.log(err) }
  })

}

const checkforotp = (req, res) => {
  resetPass.find({ email: req.body.email }, (err, docs) => {
    console.log("check for otp  " + docs.length)
    if (docs.length == 0) {
      otpnotexist(req, res)
    }
    if (docs.length > 0) {
      newotp = rn(options)
      resetPass.findOneAndUpdate({ email: req.body.email }, { otp: newotp }, (err) => { console.log(err) })
      mail(req.body.email, String(newotp))
      res.status(201).json({
        message: "Email has been send to your registered Email Id.",
        success: true
      });
    }
    else { console.log(err) }
  })
}


const otpnotexist = (req, res) => {
  const saveotp = new resetPass({
    email: req.body.email,
    otp: otp
  })
  saveotp.save()
  mail(req.body.email, String(otp))
  res.status(201).json({
    message: "Otp has been send to your registered Email Id.",
    success: true
  });
}

//-----------------------
const verify = async (req, res) => {
  console.log(req.body.otp, req.body.password, req.body.email)
  resetPass.find({ email: req.body.email }, (err, docs) => {
    console.log(docs, docs.length)
    if (docs.length == 0) {
      // res.status(201).json({
      //   message: "Please Try Again After Some Time.",
      //   success: false
      // });
    }
    if (docs.length > 0) {
      if (docs[0].otp == req.body.otp) {
        console.log("Otp Matched")
        otpMatchedChangePassword(req, res)
      }
      if (docs[0].otp != req.body.otp) {
        console.log("otp not matched")
        res.status(201).json({
          message: "Otp Not Matched.",
          success: true
        });
      }
      else {
        console.log(err)
        // res.status(201).json({
        //   message: "Email has been send to your registered Email Id.",
        //   success: true
        // });
      }
    }
    else {
      res.status(201).json({
        message: "Please Try Again After Some Time.",
        success: false
      });
    }

  })



}

const otpMatchedChangePassword = async (req, res) => {
  const passwor = await bcrypt.hash(req.body.password, 12);
  User.findOneAndUpdate({ email: req.body.email }, { password: passwor }, (err) => {
    if (!err) {
      res.status(201).json({
        message: "Password Changed Successfull",
        success: true
      });
      deletotp(req)
    }
  })
}

const deletotp = (req) => {
  resetPass.findOneAndDelete({ email: req.body.email }, (err) => {
    if (!err) { console.log("removing old otp") }
  })
}

//----------------------------

const forgetPassword = (data, res) => {
  const { email } = data;//destructure

  console.log(email)
  User.findOne({ email }, (err, docs) => {
    if (err || !docs) {
      return res.status(400).json({ error: "User Does Not Exist" })
    } else {
      const token = jwt.sign({ _id: docs._id }, process.env.RESET_PASSWORD_KEY, { expiresIn: '5m' })
      mail(email, token)
    }
  })
}

const changePassword = async (req, res) => {
  console.log(req.body.email, req.body.oldPassword, req.body.newPassword)
  const newpassword = await bcrypt.hash(req.body.newPassword, 12);
  User.find({ email: req.body.email }, (err, docs) => {
    console.log(docs)
    if (docs.length == 0) {
      console.log("User does not exist")
    }
    if (docs.length > 0) {
      console.log("user exist")
      bcrypt.compare(req.body.oldPassword, docs[0].password, function (err, result) {
        if (result == true) {
          changePasswordUsingOldPassword(req.body.email, newpassword, res)
        }
        else {
          res.status(201).json({
            message: "Old Password Does Not Match",
            success: false
          });
        }

      });
    }
    else {
      console.log(err)
    }
  })

  // bcrypt.compare("123456788", "$2a$12$0tCunhOSc.eqhjSgYb4zXekAzWM2RNUVGOQhzuIRnKES3AjbOEDBu", function (err, result) {
  //   // result == true
  //   console.log(result)
  // });

  //User.findOneAndUpdate({ email }, { name: 'jason bourne' }, options, callback)
}

const changePasswordUsingOldPassword = (email, newPassword, res) => {
  console.log(email, newPassword)
  User.findOneAndUpdate({ email: email }, { password: newPassword }, (err, docs) => {
    if (!err) {
      console.log(docs)
      res.status(201).json({
        message: "Password Changed",
        success: true
      });
    }
  })
}


const getEventEmail = (email, res) => {
  usercart.find({ email: email }, (err, docs) => {
    if (!err) {
      res.send(docs[0].eventTickets)
      console.log(docs[0].eventTickets[1])
    }
  })
}

const notifymy = (req, res) => {
  //console.log("notifymy")
  notifications.find({ email: req.body.email }, (err, docs) => {
    if (docs.length == 0) {
      console.log("zero")
      createnotifyme(req, res)
    }
    if (docs.length > 0) {
      console.log("present")
      updatenotifyme(docs,req, res)
    }
    else {
      console.log(err)
    }
  })
}

createnotifyme = (req, res) => {
  const not = new notifications({
    email: req.body.email,
    notifications: [req.body.notifications]
  })
  not.save((err,docs)=>{
    if(!err){
      res.send(docs)
    }
  })
  
}

updatenotifyme = (data,req, res) => { 
  console.log("data="+ data)
  console.log("eventid="+req.body.notifications[0].eventid)
  notifications.findOneAndUpdate({ email: req.body.email }, {
    $push: {
      notifications: [req.body.notifications],
    }
  },(err,docs)=>{
    if(!err){
      res.send(docs)
    }
    else{
      res.send(err)
    }
  })





  // notifications.find({email:req.body.email }, (err, docs) => {
  //   console.log(docs)
    
  //   // if (docs.length == 0) {
  //   //   console.log("0")
  //   //   createNewNotification(req, res)
  //   // }
  //   // if (docs.length > 0) {
  //   //   console.log(docs)
  //   // }
  //   // else {
  //   //   console.log(err)
  //   // }
  // })
}

createNewNotification = (req, res) => {
  notifications.findByIdAndUpdate({ email: req.body.email }, {
    $push: {
      notifications: {
        eventid: req.body.notifications
      },
    }
  },(err,docs)=>{
    if(!err){
      res.send(docs)
    }
    else{
      res.send(err)
    }
  })
}

deletUser = (req, res) => {
  User.findOneAndDelete({ _id: req.body.id }, (err, docs) => {
    if (!err) {
      res.json(
        {
          message: `Delete Successfull.`,
          success:true
        }
      )
    }
    else { 
      res.json(
        {
          message: `Error:- ${err}`,
          success:false
        }
      )
    }
  })
}

module.exports = {
  userAuth,
  checkRole,
  userLogin,
  userRegister,
  serializeUser,
  createEvent,
  getAllEvent,
  getUserList,
  resetPassword,
  verify,
  forgetPassword,
  changePassword,
  getEventEmail,
  notifymy,
  deletUser
};

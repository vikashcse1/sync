const router = require("express").Router();
const Event = require("../models/Event");
const cors = require("cors");

// Bring in the Event function
const {
    createEvent,
    getEvent,
    getCategory,
    getAllCategory
} = require("../utils/Event");

// Create Event
router.post("/createEvent", async (req, res) => {
  //await createEvent(req.body, "user", res);
  console.log(req.body)
  await createEvent(req.body, res);
});

// Get Event
router.get("/getEvent", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await getEvent(res);
});

// Get Event
router.get("/getCategory", async (req, res) => {
    //await getEvent(req.body, "admin", res);
    //console.log(req.body.category)
    let cat=req.body.category
    if(!cat){
      await getCategory(cat,res);
    }
    if(cat==[]){
      await getAllCategory(res);
    }
    
  });

module.exports = router;




const { Schema, model } = require("mongoose");

const UserSchema = new Schema(
  {
    name: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    },
    role: {
      type: String,
      default: "user",
      enum: ["user", "admin", "superadmin"]
    },
    phone: {
      type: String,
      required: true
    },
    password: {
      type: String,
      required: true
    },
    user_description:{
      type:String
    },
    following:{
      type:Number,
      image:[]
    }
  },
  { timestamps: true }
);

module.exports = model("users", UserSchema);

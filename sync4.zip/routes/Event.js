const router = require("express").Router();
const Event = require("../models/Event");
const cors = require("cors");

// Bring in the Event function
const {
    createEvent,
    getEvent,
    getCategory,
    getAllCategory,
    liveEvent,
    preRecorded,
    upComing,
    deleteEvent,
    like
} = require("../utils/Event");

// Create Event
router.post("/createEvent", async (req, res) => {
  //await createEvent(req.body, "user", res);
  console.log(req.body)
  await createEvent(req.body, res);
});

// Get Event
router.get("/getEvent", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await getEvent(res);
});

// Get Event
router.get("/getCategory", async (req, res) => {
    //await getEvent(req.body, "admin", res);
    //console.log(req.body.category)
    let cat=req.body.category
    if(!cat){
      await getCategory(cat,res);
    }
    if(cat==[]){
      await getAllCategory(res);
    }
    
  });

  // Get Event
router.get("/live", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await liveEvent(res);
});
// Get Event
router.get("/recoded", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await preRecorded(res);
});
// Get Event
router.get("/upcoming", async (req, res) => {
  //await getEvent(req.body, "admin", res);
  await upComing(res);
});

router.post('/delete',async(req,res)=>{
  await deleteEvent(req.body._id,res)
  console.log("delete   "+req.body._id)
})

router.post('/like',(req,res)=>{
  like(req,res)
})



module.exports = router;



